from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse
from.models import *
from django.views.generic import CreateView, DetailView, ListView, DeleteView
# Create your views here.
from django.urls import reverse_lazy
from lb1.forms import *
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.urls import reverse
from django.http import HttpResponseRedirect

@login_required
def home1(request):
    return render(request,'lb1/home.html')

# def addbook(request):
#     # addbook = lb1.addbook.objects.all()
#     return render(request,'lb1/addbook.html')

class CreateBookView(CreateView):
	fields = ['name', 'author_name', 'publication','category']
	model = Book
	template_name = 'lb1/create_book.html'



def showbook(request):
    showbooks = Addbook.objects.all()
    return render(request,'lb1/showbook.html',{'showbooks':showbooks})

def showstudent(request):
    showstudents = Addstudent.objects.all()
    return render(request,'lb1/showstudents.html',{'showstudents':showstudents})


class CreateStudentView(CreateView):
	fields = [

		'name',
		'book',
		'semester',
		'student_id',
		'father_name',
		'mobile_no',
		'aadhar',
		'address',
		'Pin_code',
	]
	model = Student
	template_name = 'lb1/create_student.html'
# def addstudent(request):
    # return render(request,'lb1/addstudent.html')

# def book_details(request):
#     return render(request,'lb1/book_details.html')
class BookListView(ListView):
	model = Book
	template_name = 'lb1/book_list.html'
	context_object_name = 'booklist'

class BookDetailView(DetailView):
	model = Book
	template_name = 'lb1/book_details.html'
	context_object_name = 'book_details'


def total_books(request):
	category = Category.objects.all()
	count = len(category)
	data = {'category': category, 'count': count}
	return render(request, 'lb1/total_books.html', context=data)


class BookDeleteView(DeleteView):
	model = Book
	template_name = 'lb1/book_delete.html'
	success_url = reverse_lazy('home1')

class BookListViewDelete(ListView):
	model = Book
	template_name = 'lb1/delete.html'
	context_object_name = 'booklist'

class StudentListView(ListView):
	model = Student
	template_name = 'lb1/student_list.html'
	context_object_name = 'student_list'

class StudentDetailView(DetailView):
	model =Student
	template_name = 'lb1/student_detail.html'
	context_object_name = 'student_detail'

class StudentListViewDelete(ListView):
	model = Student
	template_name = 'lb1/student_delete_list.html'
	context_object_name = 'student_list'

class StudentDetailViewDelete(DeleteView):
	model =Student
	template_name = 'lb1/student_delete.html'
	success_url = reverse_lazy('home1')

class CategoryBookListView(DetailView):
	model = Category
	template_name = 'lb1/category_detail.html'
	context_object_name = 'category_detail'

def search(request):
	form = SearchForm()
	search_data = False
	if request.method == "POST":
		form = SearchForm(request.POST)
		if form.is_valid():
			
			query = request.POST['book_name']
			books = Book.objects.get(name__exact=query)
			# print(books)
			search_data = books
			# print(books)
			# a=Book.objects.all()
			# print(a)
	data = {'form':form, 'search_data':search_data}
	return render(request, 'lb1/search_book.html', context=data)


def user_logout(request):
	logout(request)
	return HttpResponseRedirect(reverse('home'))