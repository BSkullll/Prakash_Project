from django import forms

class SearchForm(forms.Form):
	book_name = forms.CharField(max_length=256)