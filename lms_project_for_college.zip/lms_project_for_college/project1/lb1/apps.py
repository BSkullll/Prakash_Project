from django.apps import AppConfig


class Lb1Config(AppConfig):
    name = 'lb1'
