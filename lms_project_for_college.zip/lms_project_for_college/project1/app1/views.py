from django.shortcuts import render
from app1 import forms
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth import login as auth_login
#from .models import Students
# from .forms import StudentFrom
# Create your views here.
from django.http import HttpResponseRedirect
from django.urls import reverse

# from django.shortcuts import render, redirect
def home(request):
    return render(request,'app1/home.html')

def e_lib(request):
    return render(request,'app1/e_lib.html')

def about(request):
    return render(request,'app1/about.html')


def login(request):
	if request.method == "POST":
		username = request.POST['username']
		password = request.POST['password']

		user = authenticate(request, username=username, password=password)

		if user:
			auth_login(request, user)
			return HttpResponseRedirect(reverse('home1'))

	return render(request, 'app1/login.html')
