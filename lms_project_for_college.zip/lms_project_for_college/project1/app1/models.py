from django.db import models

# Create your models here.
# class Student_signup(models.Model):
#     image = models.ImageField(update_to='images/')
#     summary = models.CharField(max_length=300)

    #
    # return self.student_codeclass Students(models.Model):
    # student_code =models.CharField(max_length=100,unique=True)
    # student_name = models.CharField(max_length=100)
    # student_pass = models.CharField(max_length=100)
    # student_mobile =models.CharField(max_length=100, unique=True)
    # student_email = models.EmailField(unique=True)
    #
    # def __str__(self):
